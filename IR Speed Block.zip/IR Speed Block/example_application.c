/*
Filename: "main.c"
Version: 1

Created: 11/7/22
Author: Tobi Yoo

Operations: Example on how to utilize ir_speed_ctrl functions.

Hardware Connections:
Atmega2560			Hardware
*/

// Global Declarations & Libraries
#include <avr/io.h>
#include "ir_speed_ctrl.h"

// Function Prototypes
void init_io(void); // Function to initialize ports for I/O.

int main(void)
{		init_timer1_freq();
	init_mode8_pwm();
	
	while(1)
	{
		while(!(PINA & 0x01)) // Wait until button is pressed.
		{
		}
		
		float freqRead = ir_freq_read();
		ir_ctrl_pwm(freqRead);
		
		while(!(PINA & 0x01)) // Wait until button is pressed again.
		{
		}
	}
}

/*
Function: oi_init(void)
Input Parameters: None
Output Data Type: Void
Task: Initializes the general purpose ports for I/O.
*/
void init_io(void)
{
	DDRA = 0x00; // Port A as input from switches & push-buttons.
	PORTA = 0xFF; // Activate all pull-up resistors.
}